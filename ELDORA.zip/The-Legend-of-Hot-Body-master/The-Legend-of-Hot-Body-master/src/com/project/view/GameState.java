package com.project.view;

public enum GameState {
	play,
	pause,
	die,
	dialogue,
	win,
	start,
	controlsview
}
