package com.project.interfaces;

public interface AI {
	public void setAction();
}
